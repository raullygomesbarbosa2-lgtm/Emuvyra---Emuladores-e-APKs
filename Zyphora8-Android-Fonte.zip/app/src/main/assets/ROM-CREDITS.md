# Créditos das ROMs

As 49 ROMs de terceiros listadas abaixo vêm do CHIP-8 Archive. O site declara que os programas reunidos ali foram disponibilizados sob CC0 (“No Rights Reserved”): https://johnearnest.github.io/chip8Archive/. A ROM de demonstração Zyphora8 foi criada para este app.

| Arquivo | Título | Autor(es) |
|---|---|---|
| zyphora8-demo.ch8 | Zyphora8 — Demo original | Zyphora8 |
| octojam1title.ch8 | Octojam 1 Title | JohnEarnest |
| octojam2title.ch8 | Octojam 2 Title | JohnEarnest |
| octojam3title.ch8 | Octojam 3 Title | JohnEarnest |
| octojam4title.ch8 | Octojam 4 Title | JohnEarnest |
| octojam5title.ch8 | Octojam 5 Title | JohnEarnest |
| octojam6title.ch8 | Octojam 6 Title | JohnEarnest |
| octojam7title.ch8 | Octojam 7 Title | JohnEarnest |
| octojam8title.ch8 | Octojam 8 Title | JohnEarnest |
| octojam9title.ch8 | Octojam 9 Title | JohnEarnest |
| octojam10title.ch8 | Octojam 10 Title | JohnEarnest |
| fuse.ch8 | Fuse | JohnEarnest |
| slipperyslope.ch8 | Slippery Slope | JohnEarnest |
| chipwar.ch8 | ChipWar | JohnEarnest |
| caveexplorer.ch8 | Cave Explorer | JohnEarnest |
| outlaw.ch8 | Outlaw | JohnEarnest |
| RPS.ch8 | RPS | SystemLogoff |
| octoachip8story.ch8 | Octo: a Chip 8 Story | SystemLogoff |
| pumpkindressup.ch8 | Pumpkin "Dreess" Up | SystemLogoff |
| petdog.ch8 | Pet Dog | SystemLogoff |
| 8ceattourny_d1.ch8 | 8CE Attourny - Disc 1 | SystemLogoff |
| 8ceattourny_d2.ch8 | 8CE Attourny - Disc 2 | SystemLogoff |
| 8ceattourny_d3.ch8 | 8CE Attourny - Disc 3 | SystemLogoff |
| octorancher.ch8 | Octo Rancher | SystemLogoff |
| tank.ch8 | Tank! | Rectus |
| flightrunner.ch8 | Flight Runner | TodPunk |
| masquer8.ch8 | Masquer8 | Chromatophore |
| carbon8.ch8 | Carbon8 | Chromatophore |
| BadKaiJuJu.ch8 | Bad Kaiju Ju | MattBooth |
| piper.ch8 | Piper | Aeris, JordanMecom, LillianWang |
| mini-lights-out.ch8 | Mini Lights Out | tobiasvl |
| horseWorldOnline.ch8 | Horse World Online | TomRintjema |
| ghostEscape.ch8 | Ghost Escape | TomRintjema |
| tombstontipp.ch8 | TOMB STON TIPP | TomRintjema |
| br8kout.ch8 | Br8kout | SharpenedSpoon |
| 1dcell.ch8 | 1D Cellular Automata | SharpenedSpoon |
| spacejam.ch8 | Spacejam! | WilliamDonnelly |
| mastermind.ch8 | Mastermind | WilliamDonnelly |
| spaceracer.ch8 | Space Racer | WilliamDonnelly |
| down8.ch8 | down8 | tinaun |
| chipquarium.ch8 | Chipquarium | mattmik |
| glitchGhost.ch8 | Glitch Ghost | JackieKircher |
| spockpaperscissors.ch8 | Spock Paper Scissors | fontz |
| snek.ch8 | Snek | JohnEarnest |
| superpong.ch8 | Super Pong | offstatic |
| wdl.ch8 | WDL | JohnEarnest |
| knumberknower.ch8 | Knumber Knower | JohnEarnest |
| dinorun.ch8 | Dino Run | Andrezinrc |
| tick.ch8 | Tick | StanislavDidus |
| mato8.ch8 | Mato8 | nortti |
