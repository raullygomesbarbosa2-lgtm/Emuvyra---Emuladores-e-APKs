package br.com.zyphora8;

import androidx.activity.ComponentActivity;
import com.swordfish.libretrodroid.GLRetroView;
import com.swordfish.libretrodroid.GLRetroViewData;
import android.view.KeyEvent;
import android.widget.FrameLayout;
import java.io.File;
import java.io.FileOutputStream;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Locale;

public final class MainActivity extends ComponentActivity {
  private static final int PICK_ROM = 17;
  private static final int PICK_MD_ROM = 18;
  private static final int BG = Color.rgb(8, 13, 19);
  private static final int ACCENT = Color.rgb(47, 255, 193);
  private final Chip8 vm = new Chip8();
  private final Handler handler = new Handler();
  private final boolean[] keys = new boolean[16];
  private JSONArray games = new JSONArray();
  private byte[] activeRom;
  private String activeTitle = "Zyphora8 — Demo original";
  private TextView status;
  private TextView selectedGame;
  private GameView screen;
  private GLRetroView retroView;
  private boolean running;
  private int cyclesPerFrame = 8;

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(BG);
    getWindow().setNavigationBarColor(BG);
    getWindow().getDecorView().setSystemUiVisibility(0);
    readCatalog();
    buildUi();
    loadAsset("zyphora8-demo.ch8", "Zyphora8 — Demo original");
  }

  private void readCatalog() {
    try (InputStream in = getAssets().open("games.json"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
      byte[] buf = new byte[4096]; int n;
      while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
      games = new JSONArray(out.toString("UTF-8"));
    } catch (Exception ignored) { games = new JSONArray(); }
  }

  private void buildUi() {
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(dp(12), dp(8), dp(12), dp(8));
    root.setBackgroundColor(BG);

    LinearLayout header = new LinearLayout(this);
    header.setGravity(Gravity.CENTER_VERTICAL);
    LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
    TextView title = text("ZYPHORA8", 21, ACCENT, true);
    TextView subtitle = text("CHIP-8 + MEGA DRIVE  ·  50 HOME BREWS", 10, Color.rgb(142,162,177), false);
    brand.addView(title); brand.addView(subtitle);
    header.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1));
    Button catalog = button("JOGOS"); catalog.setOnClickListener(v -> showCatalog());
    Button open = button("SISTEMA"); open.setOnClickListener(v -> showSystemMenu());
    header.addView(catalog, new LinearLayout.LayoutParams(dp(78), dp(42)));
    header.addView(open, new LinearLayout.LayoutParams(dp(100), dp(42)));
    root.addView(header);

    selectedGame = text(activeTitle, 12, Color.WHITE, true);
    selectedGame.setGravity(Gravity.CENTER_VERTICAL);
    root.addView(selectedGame, new LinearLayout.LayoutParams(-1, dp(28)));

    screen = new GameView();
    LinearLayout.LayoutParams screenParams = new LinearLayout.LayoutParams(-1, 0, 1f);
    screenParams.setMargins(0, dp(2), 0, dp(4));
    root.addView(screen, screenParams);

    status = text("Pronto · escolha um jogo ou abra uma ROM", 11, Color.rgb(165,181,195), false);
    status.setGravity(Gravity.CENTER);
    root.addView(status, new LinearLayout.LayoutParams(-1, dp(24)));

    LinearLayout speed = new LinearLayout(this); speed.setGravity(Gravity.CENTER_VERTICAL);
    TextView speedLabel = text("VELOCIDADE", 10, Color.rgb(142,162,177), true);
    speed.addView(speedLabel, new LinearLayout.LayoutParams(0, dp(36), 1));
    Button slower = button("−"); slower.setOnClickListener(v -> { cyclesPerFrame = Math.max(1, cyclesPerFrame - 2); setStatus("Velocidade: " + cyclesPerFrame + " ciclos/frame"); });
    Button faster = button("+"); faster.setOnClickListener(v -> { cyclesPerFrame = Math.min(30, cyclesPerFrame + 2); setStatus("Velocidade: " + cyclesPerFrame + " ciclos/frame"); });
    speed.addView(slower, new LinearLayout.LayoutParams(dp(54), dp(36)));
    speed.addView(faster, new LinearLayout.LayoutParams(dp(54), dp(36)));
    root.addView(speed);

    GridLayout pad = new GridLayout(this); pad.setColumnCount(4); pad.setRowCount(4);
    String[] labels = {"1","2","3","C","4","5","6","D","7","8","9","E","A","0","B","F"};
    int[] map = {1,2,3,12,4,5,6,13,7,8,9,14,10,0,11,15};
    for (int i = 0; i < 16; i++) {
      final int key = map[i];
      TextView padKey = text(labels[i], 18, Color.WHITE, true);
      padKey.setGravity(Gravity.CENTER);
      padKey.setBackgroundColor(Color.rgb(24, 34, 44));
      GridLayout.LayoutParams p = new GridLayout.LayoutParams();
      p.width = 0; p.height = dp(43);
      p.columnSpec = GridLayout.spec(i % 4, 1f); p.rowSpec = GridLayout.spec(i / 4);
      p.setMargins(dp(3), dp(3), dp(3), dp(3)); pad.addView(padKey, p);
      padKey.setOnTouchListener((view, event) -> {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
          keys[key] = true; padKey.setBackgroundColor(Color.rgb(0, 145, 108)); return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL || action == MotionEvent.ACTION_POINTER_UP) {
          keys[key] = false; padKey.setBackgroundColor(Color.rgb(24, 34, 44)); return true;
        }
        return true;
      });
    }
    root.addView(pad, new LinearLayout.LayoutParams(-1, dp(190)));
    setContentView(root);
  }

  private TextView text(String value, float size, int color, boolean bold) {
    TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
    if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
    return t;
  }
  private Button button(String value) {
    Button b = new Button(this); b.setText(value); b.setTextSize(10); b.setTextColor(BG);
    b.setPadding(dp(2), 0, dp(2), 0);
    b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ACCENT)); return b;
  }
  private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
  private void setStatus(String value) { if (status != null) status.setText(value); }

  private void showCatalog() {
    if (games.length() == 0) { Toast.makeText(this, "Catálogo não carregou", Toast.LENGTH_SHORT).show(); return; }
    String[] names = new String[games.length()];
    for (int i = 0; i < games.length(); i++) names[i] = games.optJSONObject(i).optString("title", "ROM " + (i + 1));
    new AlertDialog.Builder(this).setTitle("Biblioteca CHIP-8 · " + names.length + " ROMs")
      .setItems(names, (dialog, which) -> {
        JSONObject game = games.optJSONObject(which);
        if (game != null) loadAsset(game.optString("file"), game.optString("title"));
      }).setNegativeButton("FECHAR", null).show();
  }

  private void showSystemMenu() {
    String[] systems = {"CHIP-8 · biblioteca (50 jogos)", "CHIP-8 · abrir ROM do celular", "Mega Drive · abrir ROM do celular"};
    new AlertDialog.Builder(this).setTitle("Escolher sistema")
      .setItems(systems, (dialog, which) -> {
        if (which == 0) showCatalog();
        else if (which == 1) pickRom();
        else pickMegadriveRom();
      }).setNegativeButton("FECHAR", null).show();
  }

  private void loadAsset(String file, String title) {
    try (InputStream in = getAssets().open("roms/" + file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
      byte[] buf = new byte[2048]; int n;
      while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); if (out.size() > 3584) throw new IllegalArgumentException(); }
      loadRom(out.toByteArray(), title);
    } catch (Exception e) { setStatus("Não foi possível carregar esta ROM"); }
  }

  private void pickRom() {
    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("*/*");
    startActivityForResult(intent, PICK_ROM);
  }
  private void pickMegadriveRom() {
    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("*/*");
    startActivityForResult(intent, PICK_MD_ROM);
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if ((requestCode == PICK_ROM || requestCode == PICK_MD_ROM) && resultCode == RESULT_OK && data != null && data.getData() != null) {
      Uri uri = data.getData();
      try {
        if (requestCode == PICK_MD_ROM) {
          File romFile = copyUriToFile(uri);
          startMegadrive(romFile, romFile.getName());
        } else {
          try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[2048]; int n;
            while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); if (out.size() > 3584) throw new IllegalArgumentException(); }
            loadRom(out.toByteArray(), displayName(uri));
          }
        }
      } catch (Exception e) { Toast.makeText(this, e.getMessage() == null ? "Não consegui abrir essa ROM" : e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
  }

  private String displayName(Uri uri) {
    try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
      if (cursor != null && cursor.moveToFirst()) return cursor.getString(0);
    } catch (Exception ignored) { }
    return "ROM CHIP-8";
  }

  private File copyUriToFile(Uri uri) throws Exception {
    String name = displayName(uri).replaceAll("[^A-Za-z0-9._-]", "_");
    File dir = new File(getFilesDir(), "roms");
    if (!dir.isDirectory() && !dir.mkdirs()) throw new IllegalStateException("Não consegui criar a pasta das ROMs.");
    File target = new File(dir, "md_" + System.currentTimeMillis() + "_" + name);
    try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(target)) {
      if (in == null) throw new IllegalArgumentException("Não consegui ler o arquivo escolhido.");
      byte[] buffer = new byte[64 * 1024]; int n; long total = 0;
      while ((n = in.read(buffer)) != -1) {
        total += n;
        if (total > 64L * 1024L * 1024L) throw new IllegalArgumentException("A ROM excede o limite de 64 MB.");
        out.write(buffer, 0, n);
      }
    }
    return target;
  }
  private void loadRom(byte[] rom, String title) {
    if (rom == null || rom.length == 0) { setStatus("Arquivo vazio"); return; }
    activeRom = rom.clone(); activeTitle = title; vm.load(activeRom);
    if (selectedGame != null) selectedGame.setText(title);
    setStatus("Carregada · " + rom.length + " bytes");
    if (screen != null) screen.invalidate();
  }

  private void startMegadrive(File rom, String title) {
    File core = new File(getApplicationInfo().nativeLibraryDir, "libgenesis_plus_gx_libretro_android.so");
    if (!core.isFile()) throw new IllegalStateException("O núcleo Genesis Plus GX não veio no APK.");
    File systemDir = new File(getFilesDir(), "system");
    File savesDir = new File(getFilesDir(), "saves");
    if (!systemDir.isDirectory()) systemDir.mkdirs();
    if (!savesDir.isDirectory()) savesDir.mkdirs();
    GLRetroViewData data = new GLRetroViewData(this);
    data.setCoreFilePath(core.getAbsolutePath());
    data.setGameFilePath(rom.getAbsolutePath());
    data.setSystemDirectory(systemDir.getAbsolutePath());
    data.setSavesDirectory(savesDir.getAbsolutePath());
    data.setPreferLowLatencyAudio(true);
    data.setSkipDuplicateFrames(true);

    FrameLayout gameRoot = new FrameLayout(this);
    gameRoot.setBackgroundColor(Color.BLACK);
    gameRoot.setMotionEventSplittingEnabled(true);
    retroView = new GLRetroView(this, data);
    gameRoot.addView(retroView, new FrameLayout.LayoutParams(-1, -1));
    addMegadriveControls(gameRoot, title);
    setContentView(gameRoot);
    getLifecycle().addObserver(retroView);
    retroView.setFocusableInTouchMode(true);
    retroView.requestFocus();
  }

  private void addMegadriveControls(FrameLayout parent, String title) {
    TextView gameName = text("MEGA DRIVE · " + title, 11, Color.WHITE, true);
    gameName.setBackgroundColor(0x88000000);
    gameName.setPadding(dp(8), dp(5), dp(8), dp(5));
    FrameLayout.LayoutParams nameParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
    parent.addView(gameName, nameParams);

    Button back = button("‹ VOLTAR");
    back.setOnClickListener(v -> returnToChip8());
    FrameLayout.LayoutParams backParams = new FrameLayout.LayoutParams(dp(92), dp(40), Gravity.TOP | Gravity.LEFT);
    backParams.leftMargin = dp(8); backParams.topMargin = dp(8); parent.addView(back, backParams);

    GridLayout dpad = new GridLayout(this); dpad.setColumnCount(3); dpad.setRowCount(3);
    String[] dirs = {"", "↑", "", "←", "", "→", "", "↓", ""};
    int[] directionCodes = {0,KeyEvent.KEYCODE_DPAD_UP,0,KeyEvent.KEYCODE_DPAD_LEFT,0,KeyEvent.KEYCODE_DPAD_RIGHT,0,KeyEvent.KEYCODE_DPAD_DOWN,0};
    for (int i=0;i<9;i++) {
      if (directionCodes[i]==0) { View blank=new View(this); GridLayout.LayoutParams empty=new GridLayout.LayoutParams(); empty.width=dp(48); empty.height=dp(48); empty.setMargins(dp(2),dp(2),dp(2),dp(2)); dpad.addView(blank,empty); continue; }
      Button key=retroKeyButton(dirs[i],directionCodes[i]);
      GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=dp(48); p.height=dp(48); p.setMargins(dp(2),dp(2),dp(2),dp(2));
      dpad.addView(key,p);
    }
    FrameLayout.LayoutParams dp=dpadParams(); parent.addView(dpad,dp);

    GridLayout action=new GridLayout(this); action.setColumnCount(2); action.setRowCount(2);
    String[] labels={"B","C","A","START"};
    int[] codes={KeyEvent.KEYCODE_BUTTON_B,KeyEvent.KEYCODE_BUTTON_X,KeyEvent.KEYCODE_BUTTON_A,KeyEvent.KEYCODE_BUTTON_START};
    for(int i=0;i<labels.length;i++){
      Button key=retroKeyButton(labels[i],codes[i]);
      GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=dp(54); p.height=dp(50); p.setMargins(dp(3),dp(3),dp(3),dp(3)); action.addView(key,p);
    }
    FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.RIGHT);
    ap.rightMargin=dp(12);ap.bottomMargin=dp(12);parent.addView(action,ap);
  }

  private FrameLayout.LayoutParams dpadParams() {
    FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.LEFT);
    p.leftMargin=dp(10);p.bottomMargin=dp(10);return p;
  }

  private Button retroKeyButton(String label,int keyCode) {
    Button b=button(label); b.setTextSize(13); b.setMinWidth(0); b.setMinHeight(0);
    b.setOnTouchListener((view,event)->{
      int action=event.getActionMasked(); GLRetroView target=retroView;
      if(target!=null && (action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN)) target.sendKeyEvent(KeyEvent.ACTION_DOWN,keyCode,0);
      if(target!=null && (action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL||action==MotionEvent.ACTION_POINTER_UP)) target.sendKeyEvent(KeyEvent.ACTION_UP,keyCode,0);
      return true;
    });
    return b;
  }

  private void returnToChip8() {
    GLRetroView old=retroView; retroView=null;
    if(old!=null) getLifecycle().removeObserver(old);
    buildUi();
    if(activeRom!=null) vm.load(activeRom);
    setStatus("CHIP-8 · escolha um jogo ou outro sistema");
  }

  @Override public void onBackPressed() {
    if(retroView!=null){returnToChip8();return;}
    super.onBackPressed();
  }

  private final Runnable frameLoop = new Runnable() {
    @Override public void run() {
      if (!running) return;
      if (retroView == null) {
        int mask = 0; for (int i = 0; i < 16; i++) if (keys[i]) mask |= 1 << i;
        vm.runFrame(mask, cyclesPerFrame);
        if (screen != null) screen.invalidate();
      }
      handler.postDelayed(this, 16);
    }
  };
  @Override protected void onResume() { super.onResume(); running = true; handler.post(frameLoop); }
  @Override protected void onPause() { running = false; handler.removeCallbacks(frameLoop); Arrays.fill(keys, false); super.onPause(); }

  private final class GameView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    GameView() { super(MainActivity.this); }
    @Override protected void onDraw(Canvas canvas) {
      super.onDraw(canvas); canvas.drawColor(Color.rgb(2, 7, 11));
      float cell = Math.min(getWidth() / 64f, getHeight() / 32f);
      float left = (getWidth() - 64 * cell) / 2f, top = (getHeight() - 32 * cell) / 2f;
      paint.setStyle(Paint.Style.FILL); paint.setColor(ACCENT);
      boolean[] pixels = vm.screenCopy();
      for (int y = 0; y < 32; y++) for (int x = 0; x < 64; x++) if (pixels[y * 64 + x])
        canvas.drawRect(left + x * cell, top + y * cell, left + (x + 1) * cell, top + (y + 1) * cell, paint);
      paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(1)); paint.setColor(Color.rgb(34, 51, 59));
      canvas.drawRect(left, top, left + 64 * cell, top + 32 * cell, paint);
    }
  }

  static final class Chip8 {
    private final int[] v = new int[16], mem = new int[4096], stack = new int[16];
    private final boolean[] screen = new boolean[2048];
    private int i, pc, sp, delay, sound, rng = 0xACE1;
    Chip8() { reset(); }
    synchronized void reset() {
      Arrays.fill(v, 0); Arrays.fill(mem, 0); Arrays.fill(stack, 0); Arrays.fill(screen, false);
      i = 0; pc = 0x200; sp = 0; delay = 0; sound = 0; rng = 0xACE1;
      int[] font = {0xF0,0x90,0x90,0x90,0xF0,0x20,0x60,0x20,0x20,0x70,0xF0,0x10,0xF0,0x80,0xF0,0xF0,0x10,0xF0,0x10,0xF0,0x90,0x90,0xF0,0x10,0x10,0xF0,0x80,0xF0,0x10,0xF0,0xF0,0x80,0xF0,0x90,0xF0,0xF0,0x10,0x20,0x40,0x40,0xF0,0x90,0xF0,0x90,0xF0,0xF0,0x90,0xF0,0x10,0xF0,0xF0,0x90,0xF0,0x90,0x90,0xE0,0x90,0xE0,0x90,0xE0,0xF0,0x80,0x80,0x80,0xF0,0xE0,0x90,0x90,0x90,0xE0,0xF0,0x80,0xF0,0x80,0xF0,0xF0,0x80,0xF0,0x80,0x80};
      System.arraycopy(font, 0, mem, 0, font.length);
    }
    synchronized void load(byte[] rom) { reset(); for (int n = 0; n < rom.length && n < 4096 - 0x200; n++) mem[0x200 + n] = rom[n] & 255; }
    synchronized void runFrame(int mask, int cycles) {
      for (int c = 0; c < cycles; c++) step(mask);
      if (delay > 0) delay--; if (sound > 0) sound--;
    }
    synchronized boolean[] screenCopy() { return screen.clone(); }
    private int fetch() { int op = (mem[pc] << 8) | mem[(pc + 1) & 4095]; pc = (pc + 2) & 4095; return op; }
    private void step(int mask) {
      int op = fetch(), x = (op >>> 8) & 15, y = (op >>> 4) & 15, n = op & 15, kk = op & 255, nnn = op & 4095;
      switch (op & 0xF000) {
        case 0x0000: if (op == 0x00E0) Arrays.fill(screen, false); else if (op == 0x00EE && sp > 0) pc = stack[--sp]; break;
        case 0x1000: pc = nnn; break;
        case 0x2000: if (sp < 16) { stack[sp++] = pc; pc = nnn; } break;
        case 0x3000: if (v[x] == kk) pc = (pc + 2) & 4095; break;
        case 0x4000: if (v[x] != kk) pc = (pc + 2) & 4095; break;
        case 0x5000: if (n == 0 && v[x] == v[y]) pc = (pc + 2) & 4095; break;
        case 0x6000: v[x] = kk; break;
        case 0x7000: v[x] = (v[x] + kk) & 255; break;
        case 0x8000:
          switch (n) {
            case 0: v[x] = v[y]; break; case 1: v[x] |= v[y]; break; case 2: v[x] &= v[y]; break; case 3: v[x] ^= v[y]; break;
            case 4: { int sum = v[x] + v[y]; v[15] = sum > 255 ? 1 : 0; v[x] = sum & 255; break; }
            case 5: { int a = v[x]; v[15] = a >= v[y] ? 1 : 0; v[x] = (a - v[y]) & 255; break; }
            case 6: v[15] = v[x] & 1; v[x] = (v[x] >>> 1) & 255; break;
            case 7: { int a = v[y] - v[x]; v[15] = v[y] >= v[x] ? 1 : 0; v[x] = a & 255; break; }
            case 14: v[15] = (v[x] >>> 7) & 1; v[x] = (v[x] << 1) & 255; break;
          } break;
        case 0x9000: if (n == 0 && v[x] != v[y]) pc = (pc + 2) & 4095; break;
        case 0xA000: i = nnn; break;
        case 0xB000: pc = (nnn + v[0]) & 4095; break;
        case 0xC000: rng = (rng >>> 1) ^ (-(rng & 1) & 0xB400); v[x] = (rng & 255) & kk; break;
        case 0xD000: {
          int px = v[x] & 63, py = v[y] & 31; v[15] = 0;
          for (int row = 0; row < n; row++) { int bits = mem[(i + row) & 4095];
            for (int col = 0; col < 8; col++) if ((bits & (0x80 >>> col)) != 0) {
              int at = ((py + row) & 31) * 64 + ((px + col) & 63); if (screen[at]) v[15] = 1; screen[at] = !screen[at];
            }
          } break;
        }
        case 0xE000: if (kk == 0x9E && v[x] < 16 && (mask & (1 << v[x])) != 0) pc = (pc + 2) & 4095; else if (kk == 0xA1 && (v[x] >= 16 || (mask & (1 << v[x])) == 0)) pc = (pc + 2) & 4095; break;
        case 0xF000:
          switch (kk) {
            case 0x07: v[x] = delay; break;
            case 0x0A: { int pressed = -1; for (int q = 0; q < 16; q++) if ((mask & (1 << q)) != 0) { pressed = q; break; } if (pressed < 0) pc = (pc - 2) & 4095; else v[x] = pressed; break; }
            case 0x15: delay = v[x]; break; case 0x18: sound = v[x]; break; case 0x1E: i = (i + v[x]) & 4095; break;
            case 0x29: i = (v[x] & 15) * 5; break;
            case 0x33: mem[i] = v[x] / 100; mem[(i + 1) & 4095] = (v[x] / 10) % 10; mem[(i + 2) & 4095] = v[x] % 10; break;
            case 0x55: for (int q = 0; q <= x; q++) mem[(i + q) & 4095] = v[q]; break;
            case 0x65: for (int q = 0; q <= x; q++) v[q] = mem[(i + q) & 4095]; break;
          } break;
      }
    }
  }
}
