# Zyphora8 — emulador Android nativo

Sem WebView. O app reúne CHIP-8 e Mega Drive no mesmo APK.

## Recursos
- 50 programas CHIP-8 para uso offline: 49 listados como CC0 pelo CHIP-8 Archive e uma demo original.
- Mega Drive via Genesis Plus GX, com controles virtuais na tela.
- Importação de ROMs CHIP-8 e Mega Drive pelo seletor de arquivos do Android.
- Interface nativa Android em Java; não usa WebView.

## ROMs e licenças
Os programas CHIP-8 vêm do [CHIP-8 Archive](https://johnearnest.github.io/chip8Archive/), que declara que a coleção foi disponibilizada sob CC0. Títulos e créditos ficam em `app/src/main/assets/games.json` e `app/src/main/assets/ROM-CREDITS.md`.

O núcleo Genesis Plus GX é obtido da fonte pública do projeto durante o build e sua licença é copiada para o APK. ROMs comerciais de Mega Drive não vêm incluídas; importe apenas arquivos que você tem direito de usar.

## Build
O workflow do GitHub instala JDK, Gradle e Android NDK, compila o núcleo Genesis Plus GX para ARMv7 e ARM64 e gera o APK debug. Para compilar localmente, são necessários JDK 17, Android SDK 35, Android NDK 27.2.12479018 e Gradle 8.7.

## Compatibilidade
O interpretador embarcado implementa CHIP-8 clássico; ROMs Super-CHIP/XO-CHIP podem não funcionar. O build debug usa assinatura temporária do CI, então atualizações posteriores podem exigir desinstalar a versão anterior.
