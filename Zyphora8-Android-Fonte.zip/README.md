# Zyphora8 — emulador Android CHIP-8

Projeto Android nativo em Java, sem WebView e sem dependências externas em runtime.

## O que tem
- Interpretador CHIP-8 implementado no projeto.
- Catálogo offline de 50 programas/ROMs: 49 programas do CHIP-8 Archive identificados como CC0 e uma demo original Zyphora8.
- Controles virtuais 4×4 com toque simultâneo.
- Abrir ROM externa pelo seletor de arquivos do Android.
- Ajuste de velocidade (ciclos por frame).

## Direitos das ROMs incluídas
O CHIP-8 Archive declara que reúne programas CHIP-8 colocados sob Creative Commons Zero (CC0), sem direitos reservados: https://johnearnest.github.io/chip8Archive/

A lista de títulos e autores que acompanha o app está em `app/src/main/assets/games.json`. A demo `zyphora8-demo.ch8` foi criada para este projeto. Não há ROM de jogo comercial incluída.

## Compilar
Abra esta pasta no Android Studio com Android SDK 35 e JDK 17, ou compile pelo Gradle:

```sh
gradle assembleDebug
```

O APK debug ficará em `app/build/outputs/apk/debug/app-debug.apk`. O APK debug é para teste e não usa chave de assinatura de distribuição.

## Nota de compatibilidade
O app implementa o conjunto de instruções CHIP-8 clássico. ROMs externas de Super-CHIP/XO-CHIP ou que dependam de quirks específicos podem não funcionar corretamente.
